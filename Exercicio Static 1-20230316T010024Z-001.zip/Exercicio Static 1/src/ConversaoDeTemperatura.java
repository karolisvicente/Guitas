public class ConversaoDeTemperatura {

    public static double converteCelsiusFahrenheit(double celsius){
      double resultado = (celsius * 1.8) + 32;
      return  resultado;
    };

    public static double converteFahrenheitCelsius(double fahrenheit){
        double resultado = (fahrenheit-32)/1.8;
        return resultado;
    };
}
