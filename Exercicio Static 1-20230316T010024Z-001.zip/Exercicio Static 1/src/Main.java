public class Main {
    public static void main(String[] args) {
        double resultado;
        resultado = ConversaoDeTemperatura.converteCelsiusFahrenheit(0);
        System.out.println("0 Celsius para fahrenheit " + resultado);

        resultado = ConversaoDeTemperatura.converteCelsiusFahrenheit(100);
        System.out.println("100 Celsius para fahrenheit " + resultado);

        resultado = ConversaoDeTemperatura.converteFahrenheitCelsius(50);
        System.out.println("50 fahrenheit para celsius " + resultado);

        
    }
}